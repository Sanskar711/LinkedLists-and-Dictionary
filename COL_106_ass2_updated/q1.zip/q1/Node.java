public class Node { 
    
        public int data; 
        public Node next; 
    
        // Constructor 
        public Node(int d) 
        { 
            data = d; 
            next = null; 
        } 
    }